package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.daoservices.*;
public class PayrollDAOServicesImpl implements PayrollDAOServices{

	private static Associate[] associateList = new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;

	@Override
	public int insertAssociate(Associate associate){
		if(ASSOCIATE_IDX_COUNTER>=0.7*associateList.length){
			Associate [] temp = new Associate[associateList.length+10];
			System.arraycopy(associateList, 0, temp, 0, 10);
			associateList=temp;
		}
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++){
			if(associateList[i]!=null && associate.getAssociateID()==associateList[i].getAssociateID())
				associateList[i]=associate;
			return true;
		}
		return false;
	}
	@Override
	public boolean deleteAssociate(int associateId){
		for(int i=0;i<associateList.length;i++){
			if(associateList[i]!=null && associateList[i].getAssociateID()==associateId)
				associateList[i]=null;
			return true;
		}
		return false;
	}
	@Override
	public Associate getAssociate(int associateId){
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null && associateList[i].getAssociateID()==associateId)
				return associateList[i];

		return null;
	}
	@Override
	public Associate[] getAssociates(){
		return associateList;
	}

}
